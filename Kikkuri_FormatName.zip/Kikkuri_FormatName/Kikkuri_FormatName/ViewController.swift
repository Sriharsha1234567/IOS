//
//  ViewController.swift
//  Kikkuri_FormatName
//
//  Created by Kikkuri,Sri Harsha on 2/9/22.
//

import UIKit

class ViewController: UIViewController {
    
    

    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onClickOfSubmit(_ sender: Any) {
        var fname = firstNameTextField.text!
        var lname = lastNameTextField.text!
        displayLabel.text = "\(lname), \(fname)"
        
        
        
    }
    
    @IBAction func onClickOfReset(_ sender: Any) {
        displayLabel.text = nil
        firstNameTextField.text = nil
        lastNameTextField.text = nil
        firstNameTextField.becomeFirstResponder();
        
    }
    
}

